package com.example.demo.dto;

public class CourseChapterDto {
	private long id;
	private String name;
	private String contents;
	private String rating;
	
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public CourseChapterDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseChapterDto(String name, String contents) {
		super();
		this.name = name;
		this.contents = contents;
	}
	@Override
	public String toString() {
		return "CourseChapter [name=" + name + ", contents=" + contents + "]";
	}
	public CourseChapterDto(String name, String contents, String rating) {
		super();
//		this.id = id;
		this.name = name;
		this.contents = contents;
		this.rating = rating;
	}
	
}
