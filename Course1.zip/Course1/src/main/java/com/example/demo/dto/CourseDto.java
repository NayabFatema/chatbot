package com.example.demo.dto;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.JoinColumn;

import com.example.demo.entity.CourseChapter;

public class CourseDto {
	private long id;
	private String name;
	private LocalDate date;
	private String Description;
	private List<CourseChapter> chapter;
	private String courseRating;
	
	
	
	public String getCourseRating() {
		return courseRating;
	}
	public void setCourseRating(String courseRating) {
		this.courseRating = courseRating;
	}
	public List<CourseChapter> getChapter() {
		return chapter;
	}
	public void setChapter(List<CourseChapter> chapter) {
		this.chapter = chapter;
	}
	private String Domain;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public List<CourseChapter> getChapters() {
		return chapters;
	}
	public void setChapters(List<CourseChapter> chapters) {
		this.chapters = chapters;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	private List<CourseChapter> chapters;
	public CourseDto(String name, String description, String domain) {
		super();
		this.name = name;
		Description = description;
		Domain = domain;
	}
	public CourseDto(String name, LocalDate localDate, String description, String string) {
		super();
		this.name = name;
		this.date = localDate;
		Description = description;
		Domain = string;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getDomain() {
		return Domain;
	}
	@Override
	public String toString() {
		return "CourseDto [id=" + id + ", name=" + name + ", date=" + date + ", Description=" + Description
				+ ", chapter=" + chapter + ", Domain=" + Domain + ", chapters=" + chapters + "]";
	}

}
