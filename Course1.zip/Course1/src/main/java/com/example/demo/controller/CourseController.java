package com.example.demo.controller;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CourseDto;
import com.example.demo.entity.Course;
import com.example.demo.entity.CourseChapter;
import com.example.demo.repository.CourseRepository;
import com.example.demo.service.CourseService;

@RestController

public class CourseController {
	
	@Autowired
	private CourseService service;
	
	@Autowired
	private CourseRepository repo;
	
	@GetMapping("/course")
	public ResponseEntity<List<Course>> getAllCourse() {
		
		List<Course> course = service.getCourse();
		return ResponseEntity.ok(course);
		
	}
	
	@GetMapping("/courses")
	public ResponseEntity<List<Course>> getCourses(@RequestParam(name = "sort", defaultValue = "date") String sortMode, 
	                                                @RequestParam(name = "domain", required = false) String domain) {
	    List<Course> courses = service.getCourse();
	    if (domain != null) {
	        courses = courses.stream().filter(course -> course.getDomain().equals(domain)).collect(Collectors.toList());
	    }
	  
	    switch (sortMode) {
	        case "alphabetical":
	            courses.sort(Comparator.comparing(Course::getName)); 
	            break;
	        case "date":
	            courses.sort(Comparator.comparing(Course::getDate).reversed());
	            break;
	        
	        default:
	            break;
	    }
	    return ResponseEntity.ok(courses);
	}
	
	
	
	
	
	
	

}
