package com.example.demo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.example.demo.dto.CourseChapterDto;
import com.example.demo.dto.CourseDto;
import com.example.demo.entity.CourseChapter;
import com.example.demo.service.CourseService;






@SpringBootApplication
public class SpringDataDemo30March1Application implements CommandLineRunner {
	
	@Autowired
	private CourseService service;
	
	

	public static void main(String[] args) {
		SpringApplication.run(SpringDataDemo30March1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub


//		list.add(new CourseChapter("Gil Strang's Introduction to Calculus for Highlights for High School", "Highlights of Calculus"));
		
		CourseDto dto1 = new CourseDto("Highlights of Calculus", LocalDate.now(), "college students, or anyone who might need help understanding the subject.",   "mathematics");
		List<CourseChapterDto> directorList = Arrays.asList(
				new CourseChapterDto("Gil Strang's Introduction to Calculus for Highlights for High School", "Highlights of Calculus","positive"),
				new CourseChapterDto("Big Picture of Calculus",
		                "Highlights of Calculus")
				);
		
//		CourseDto dto1 = new CourseDto("Moon of Calculus", LocalDate.of(2023, 04, 12), "Office collegues, or anyone who might need help understanding the subject.",   "brogramming");
//		List<CourseChapterDto> directorList = Arrays.asList(
//				new CourseChapterDto("Gil Strang's Introduction to Calculus for Highlights for High School", "Highlights of Calculus","positive"),
//				new CourseChapterDto("Big Picture of Calculus",
//		                "Highlights of Calculus","negative")
//				);
//		service.createCourse(dto1,directorList);
		
//		service.getCourse();
//		service.deleteAll();
			}
		
		
		
	
	

}
