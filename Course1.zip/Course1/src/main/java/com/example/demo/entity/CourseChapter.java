package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class CourseChapter {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private String contents;
	private String rating;
	
	
	
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public CourseChapter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseChapter(String name, String contents) {
		super();
		this.name = name;
		this.contents = contents;
	}
	@Override
	public String toString() {
		return "CourseChapter [name=" + name + ", contents=" + contents + "]";
	}
	public CourseChapter( String name, String contents, String rating) {
		super();
		
		this.name = name;
		this.contents = contents;
		this.rating = rating;
	}
	public CourseChapter(long id, String name, String contents) {
		super();
		this.id = id;
		this.name = name;
		this.contents = contents;
	}
	
	
}
