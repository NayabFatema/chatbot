package com.example.demo.entity;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Course {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private LocalDate date;
	private String Description;
//	@ElementCollection @CollectionTable(name = "course_domain", joinColumns = @JoinColumn(name = "course_id"))
	private String Domain;
	private String courseRating;
	
	@Access(AccessType.PROPERTY)
	 @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JoinColumn(name="userId")
//	 @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	    @JoinColumn(name = "course_id")
	private List<CourseChapter> chapter;
	
	
	public String getCourseRating() {
		return courseRating;
	}
	public void setCourseRating(String courseRating) {
		this.courseRating = courseRating;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate localDate) {
		this.date = localDate;
	}
	
	public List<CourseChapter> getChapter() {
		return chapter;
	}
	public void setChapter(List<CourseChapter> chapter) {
		this.chapter = chapter;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	
	public Course(String name, String description, String domain) {
		super();
		this.name = name;
		Description = description;
		Domain = domain;
	}
	public Course(long id, String name, LocalDate date, String description, String domain,
			List<CourseChapter> chapters) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		Description = description;
		Domain = domain;
		this.chapter = chapters;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return Description;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getDomain() {
		return Domain;
	}
	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", date=" + date + ", Description=" + Description + ", Domain="
				+ Domain + ", chapter=" + chapter + "]";
	}
	

}
