package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

import com.example.demo.dto.CourseChapterDto;
import com.example.demo.dto.CourseDto;
import com.example.demo.entity.Course;
import com.example.demo.entity.CourseChapter;
import com.example.demo.repository.CourseRepository;


@Service
public class CourseService {
	
	@Autowired
	private CourseRepository repo;
	public void createCourse(CourseDto dto, List<CourseChapterDto> cdto) {
		Course c = new Course();
		c.setName(dto.getName());
		c.setDate(dto.getDate());
		c.setDescription(dto.getDescription());
		c.setChapter(dto.getChapters());
       c.setDomain(dto.getDomain());
       
       
       
List<CourseChapter> chap = cdto.stream()
.map(chapdto -> new CourseChapter(chapdto.getName(),chapdto.getContents(),chapdto.getRating()))
.collect(Collectors.toList());
       

       
    
       
       
       
c.setChapter(chap);

repo.save(c);
	}
	
	public List<Course> getCourse() {
		List<Course> c = repo.findAll();
		for(Course course: c) {
			System.out.println(c);
		}
		return c;
	}
	
	public void deleteAll() {
		repo.deleteAll();
	}
	
}
